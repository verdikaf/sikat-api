<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class t_kategori_logistik extends Model
{
    protected $table = 't_kategori_logistik';
    protected $fillable = ['jenis_kategori'];
    public $timestamps = false;
}
